export default async function handler(req, res) {
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return res.status(405).json({ error: "Method not allowed" });
  }

  const apiKey = process.env.FISH_API_KEY;
  const defaultReferenceId = process.env.FISH_REFERENCE_ID || "c84373c138c04287ba30cd5f245c1513";

  if (!apiKey) {
    return res.status(500).json({ error: "Missing FISH_API_KEY" });
  }

  const body = typeof req.body === "string" ? JSON.parse(req.body || "{}") : req.body || {};
  const text = String(body.text || "").slice(0, 2400);
  const referenceId = String(body.reference_id || defaultReferenceId);
  const speed = Number(body.speed || 0.94);

  if (!text.trim()) {
    return res.status(400).json({ error: "Missing text" });
  }

  const response = await fetch("https://api.fish.audio/v1/tts", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
      model: "s2-pro"
    },
    body: JSON.stringify({
      text,
      reference_id: referenceId,
      format: "mp3",
      prosody: {
        speed
      }
    })
  });

  if (!response.ok) {
    const errorText = await response.text().catch(() => "");
    return res.status(response.status).json({ error: "Fish Audio request failed", detail: errorText.slice(0, 500) });
  }

  const arrayBuffer = await response.arrayBuffer();
  res.setHeader("Content-Type", "audio/mpeg");
  res.setHeader("Cache-Control", "no-store");
  return res.status(200).send(Buffer.from(arrayBuffer));
}
