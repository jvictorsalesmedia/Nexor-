import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  if (req.method !== "POST") {
    return Response.json({ error: "Method not allowed" }, { status: 405, headers: corsHeaders });
  }

  const apiKey = Deno.env.get("FISH_API_KEY");
  const defaultReferenceId = Deno.env.get("FISH_REFERENCE_ID") ?? "c84373c138c04287ba30cd5f245c1513";

  if (!apiKey) {
    return Response.json({ error: "Missing FISH_API_KEY" }, { status: 500, headers: corsHeaders });
  }

  const body = await req.json().catch(() => ({}));
  const text = String(body.text ?? "").slice(0, 2400);
  const referenceId = String(body.reference_id ?? defaultReferenceId);
  const speed = Number(body.speed ?? 0.94);

  if (!text.trim()) {
    return Response.json({ error: "Missing text" }, { status: 400, headers: corsHeaders });
  }

  const fishResponse = await fetch("https://api.fish.audio/v1/tts", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
      model: "s2-pro",
    },
    body: JSON.stringify({
      text,
      reference_id: referenceId,
      format: "mp3",
      prosody: { speed },
    }),
  });

  if (!fishResponse.ok) {
    const detail = await fishResponse.text().catch(() => "");
    return Response.json(
      { error: "Fish Audio request failed", detail: detail.slice(0, 500) },
      { status: fishResponse.status, headers: corsHeaders },
    );
  }

  const audio = await fishResponse.arrayBuffer();
  return new Response(audio, {
    status: 200,
    headers: {
      ...corsHeaders,
      "Content-Type": "audio/mpeg",
      "Cache-Control": "no-store",
    },
  });
});
