# Deploy do Nexor

## Estado deste pacote

Este diretorio ja esta pronto para deploy estatico:

- `index.html` e a entrada publica do site.
- `vercel.json` define configuracao basica para Vercel.
- `supabase/migrations/20260618100000_nexor_core.sql` cria o banco inicial com RLS.
- `supabase/functions/whatsapp-webhook` prepara o webhook de WhatsApp.

## GitHub

Nesta sessao, o conector GitHub nao tem nenhuma conta/repo instalado e o computador nao tem `git`/`gh` no PATH.

Para publicar:

1. Crie um repositorio chamado `nexor`.
2. Suba todos os arquivos desta pasta `outputs`.
3. Use `main` como branch padrao.

## Vercel

Nesta sessao, a CLI `vercel` nao esta no PATH e nao apareceu conector de deploy direto.

Para publicar:

1. Entre na Vercel.
2. Clique em **Add New > Project**.
3. Importe o repositorio GitHub `nexor`.
4. Framework: **Other**.
5. Build command: vazio.
6. Output directory: vazio.
7. Deploy.

## Supabase

Projeto encontrado na conta: `Artes-Lion-Manager` (`hhzhrwauixyzvblzqrrt`).

Recomendado: criar um projeto novo chamado `Nexor`, para nao misturar dados com outro sistema.

Depois de escolher o projeto:

1. Rode a migration `supabase/migrations/20260618100000_nexor_core.sql`.
2. Crie o usuario `jvgsales72@gmail.com` no Supabase Auth.
3. Promova esse usuario a admin:

```sql
update public.nexor_profiles
set app_role = 'admin'
where email = 'jvgsales72@gmail.com';
```

4. Cadastre as variaveis do `.env.example` na Vercel.
5. Deploy da Edge Function `whatsapp-webhook`, se for usar WhatsApp.

## Observacoes de seguranca

- Nao coloque `service_role` no frontend.
- Use apenas a anon/publishable key no navegador.
- As tabelas publicas estao com RLS ativado.
- As policies isolam os dados por `auth.uid()`.

## Modelo de voz personalizado

A versao publicada na Vercel usa `/api/fish-tts` para gerar a fala com Fish Audio.

Modelo configurado:

```text
c84373c138c04287ba30cd5f245c1513
```

URL do modelo:

```text
https://fish.audio/m/c84373c138c04287ba30cd5f245c1513
```

Para usar um modelo de voz criado por voce, envie uma destas opcoes:

1. Nome do provedor, `voice_id`/`model_id` e link da documentacao da API.
2. Um endpoint HTTPS que receba `{ "text": "..." }` e devolva audio `mp3` ou `wav`.
3. Um arquivo ZIP com a documentacao do modelo e exemplo de chamada.

Nao envie chaves secretas no HTML. A chave deve ficar em variaveis da Vercel ou secrets do Supabase Edge Functions.

Se o modelo for clone de uma voz real, use apenas voz propria ou com autorizacao explicita da pessoa.

### Vercel

Configure estas variaveis:

```text
FISH_API_KEY=...
FISH_REFERENCE_ID=c84373c138c04287ba30cd5f245c1513
```

### Supabase Edge Function

Tambem foi criada a funcao `supabase/functions/fish-tts`.

Configure secrets:

```bash
supabase secrets set FISH_API_KEY=...
supabase secrets set FISH_REFERENCE_ID=c84373c138c04287ba30cd5f245c1513
```
