# Deploy do Nexor

## Estado deste pacote

Este diretorio ja esta pronto para deploy estatico:

- `index.html` e a entrada publica do site.
- `vercel.json` define configuracao basica para Vercel.
- `supabase/migrations/20260618100000_nexor_core.sql` cria o banco inicial com RLS.
- `supabase/functions/whatsapp-webhook` prepara o webhook de WhatsApp.

## GitHub

Nesta sessao, o conector GitHub nao tem nenhuma conta/repo instalado e o computador nao tem `git`/`gh` no PATH.

Para publicar:

1. Crie um repositorio chamado `nexor`.
2. Suba todos os arquivos desta pasta `outputs`.
3. Use `main` como branch padrao.

## Vercel

Nesta sessao, a CLI `vercel` nao esta no PATH e nao apareceu conector de deploy direto.

Para publicar:

1. Entre na Vercel.
2. Clique em **Add New > Project**.
3. Importe o repositorio GitHub `nexor`.
4. Framework: **Other**.
5. Build command: vazio.
6. Output directory: vazio.
7. Deploy.

## Supabase

Projeto encontrado na conta: `Artes-Lion-Manager` (`hhzhrwauixyzvblzqrrt`).

Recomendado: criar um projeto novo chamado `Nexor`, para nao misturar dados com outro sistema.

Depois de escolher o projeto:

1. Rode a migration `supabase/migrations/20260618100000_nexor_core.sql`.
2. Crie o usuario `jvgsales72@gmail.com` no Supabase Auth.
3. Promova esse usuario a admin:

```sql
update public.nexor_profiles
set app_role = 'admin'
where email = 'jvgsales72@gmail.com';
```

4. Cadastre as variaveis do `.env.example` na Vercel.
5. Deploy da Edge Function `whatsapp-webhook`, se for usar WhatsApp.

## Observacoes de seguranca

- Nao coloque `service_role` no frontend.
- Use apenas a anon/publishable key no navegador.
- As tabelas publicas estao com RLS ativado.
- As policies isolam os dados por `auth.uid()`.
