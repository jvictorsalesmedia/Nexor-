# Deploy do Nexor

## Estado deste pacote

Este diretorio ja esta pronto para deploy estatico:

- `index.html` e a entrada publica do site.
- `api/config.js` entrega para o frontend apenas a URL e a chave publica do Supabase.
- `vercel.json` define configuracao basica para Vercel.
- `supabase/migrations/20260618100000_nexor_core.sql` cria o banco inicial com RLS.
- `supabase/functions/nexor-admin-user` permite que o admin crie, altere senha, ative/inative e remova logins no Supabase Auth.
- `supabase/functions/whatsapp-webhook` prepara o webhook de WhatsApp.

## GitHub

Nesta sessao, o conector GitHub nao tem nenhuma conta/repo instalado e o computador nao tem `git`/`gh` no PATH.

Para publicar:

1. Crie um repositorio chamado `nexor`.
2. Suba todos os arquivos desta pasta `outputs`.
3. Use `main` como branch padrao.

## Vercel

Nesta sessao, a CLI `vercel` nao esta no PATH e nao apareceu conector de deploy direto.

Para publicar:

1. Entre na Vercel.
2. Clique em **Add New > Project**.
3. Importe o repositorio GitHub `nexor`.
4. Framework: **Other**.
5. Build command: vazio.
6. Output directory: vazio.
7. Deploy.

Variaveis para cadastrar na Vercel:

- `SUPABASE_URL`
- `SUPABASE_ANON_KEY` ou `SUPABASE_PUBLISHABLE_KEY`

Nao coloque `SUPABASE_SERVICE_ROLE_KEY` na Vercel para o frontend.

## Supabase

Projeto encontrado na conta: `Artes-Lion-Manager` (`hhzhrwauixyzvblzqrrt`).

Recomendado: criar um projeto novo chamado `Nexor`, para nao misturar dados com outro sistema.

Depois de escolher o projeto:

1. Rode a migration `supabase/migrations/20260618100000_nexor_core.sql`.
2. Crie o usuario `jvgsales72@gmail.com` no Supabase Auth.
3. Promova esse usuario a admin:

```sql
update public.nexor_profiles
set app_role = 'admin'
where email = 'jvgsales72@gmail.com';
```

4. Cadastre `SUPABASE_URL` e `SUPABASE_ANON_KEY` na Vercel.
5. Cadastre `SUPABASE_SERVICE_ROLE_KEY` como secret da Supabase Function:

```bash
supabase secrets set SUPABASE_SERVICE_ROLE_KEY=cole_a_service_role_key
```

6. Deploy da Edge Function de usuarios:

```bash
supabase functions deploy nexor-admin-user
```

7. Deploy da Edge Function `whatsapp-webhook`, se for usar WhatsApp.

Depois disso, qualquer login criado pelo painel **Acessos** do Nexor fica disponivel em qualquer dispositivo.

## Observacoes de seguranca

- Nao coloque `service_role` no frontend.
- Use apenas a anon/publishable key no navegador.
- As tabelas publicas estao com RLS ativado.
- As policies isolam os dados por `auth.uid()`.
- Usuarios inativos ficam bloqueados no app e nas policies dos registros.
- A tabela `nexor_user_password_notes` existe para o admin visualizar a senha inicial definida no Nexor. Em producao rigorosa, prefira redefinicao de senha em vez de guardar senha visivel.
