create extension if not exists pgcrypto;

create schema if not exists nexor_private;

create table if not exists public.nexor_profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text not null,
  full_name text,
  app_role text not null default 'colaborador' check (app_role in ('admin', 'gestor', 'colaborador')),
  status text not null default 'ativo' check (status in ('ativo', 'inativo')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.nexor_records (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  record_type text not null check (
    record_type in (
      'task',
      'project',
      'client',
      'finance',
      'production',
      'habit',
      'employee',
      'calendar_event',
      'notification',
      'setting'
    )
  ),
  data jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.nexor_audit_log (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  action text not null,
  record_type text,
  record_id uuid,
  data jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists public.nexor_whatsapp_inbox (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid references auth.users(id) on delete set null,
  phone text,
  message text not null,
  parsed_type text,
  parsed_data jsonb not null default '{}'::jsonb,
  status text not null default 'novo' check (status in ('novo', 'processado', 'erro')),
  created_at timestamptz not null default now()
);

create index if not exists nexor_records_owner_type_idx on public.nexor_records(owner_id, record_type);
create index if not exists nexor_records_data_gin_idx on public.nexor_records using gin(data);
create index if not exists nexor_audit_owner_created_idx on public.nexor_audit_log(owner_id, created_at desc);
create index if not exists nexor_whatsapp_owner_created_idx on public.nexor_whatsapp_inbox(owner_id, created_at desc);

create or replace function nexor_private.set_updated_at()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists set_nexor_profiles_updated_at on public.nexor_profiles;
create trigger set_nexor_profiles_updated_at
before update on public.nexor_profiles
for each row execute function nexor_private.set_updated_at();

drop trigger if exists set_nexor_records_updated_at on public.nexor_records;
create trigger set_nexor_records_updated_at
before update on public.nexor_records
for each row execute function nexor_private.set_updated_at();

create or replace function nexor_private.create_profile_for_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.nexor_profiles (id, email, full_name)
  values (
    new.id,
    coalesce(new.email, ''),
    coalesce(new.raw_user_meta_data ->> 'full_name', split_part(coalesce(new.email, ''), '@', 1))
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists create_nexor_profile_on_signup on auth.users;
create trigger create_nexor_profile_on_signup
after insert on auth.users
for each row execute function nexor_private.create_profile_for_new_user();

alter table public.nexor_profiles enable row level security;
alter table public.nexor_records enable row level security;
alter table public.nexor_audit_log enable row level security;
alter table public.nexor_whatsapp_inbox enable row level security;

grant usage on schema public to authenticated;
grant select, insert, update, delete on public.nexor_profiles to authenticated;
grant select, insert, update, delete on public.nexor_records to authenticated;
grant select, insert, update, delete on public.nexor_audit_log to authenticated;
grant select, insert, update, delete on public.nexor_whatsapp_inbox to authenticated;

drop policy if exists "profiles_select_own_or_admin" on public.nexor_profiles;
create policy "profiles_select_own_or_admin"
on public.nexor_profiles
for select
to authenticated
using (
  id = auth.uid()
  or exists (
    select 1 from public.nexor_profiles p
    where p.id = auth.uid()
      and p.app_role = 'admin'
      and p.status = 'ativo'
  )
);

drop policy if exists "profiles_update_own_or_admin" on public.nexor_profiles;
create policy "profiles_update_own_or_admin"
on public.nexor_profiles
for update
to authenticated
using (
  id = auth.uid()
  or exists (
    select 1 from public.nexor_profiles p
    where p.id = auth.uid()
      and p.app_role = 'admin'
      and p.status = 'ativo'
  )
)
with check (
  id = auth.uid()
  or exists (
    select 1 from public.nexor_profiles p
    where p.id = auth.uid()
      and p.app_role = 'admin'
      and p.status = 'ativo'
  )
);

drop policy if exists "records_owner_crud" on public.nexor_records;
create policy "records_owner_crud"
on public.nexor_records
for all
to authenticated
using (owner_id = auth.uid())
with check (owner_id = auth.uid());

drop policy if exists "audit_owner_read_insert" on public.nexor_audit_log;
create policy "audit_owner_read_insert"
on public.nexor_audit_log
for all
to authenticated
using (owner_id = auth.uid())
with check (owner_id = auth.uid());

drop policy if exists "whatsapp_owner_read" on public.nexor_whatsapp_inbox;
create policy "whatsapp_owner_read"
on public.nexor_whatsapp_inbox
for select
to authenticated
using (owner_id = auth.uid());

drop policy if exists "whatsapp_owner_update" on public.nexor_whatsapp_inbox;
create policy "whatsapp_owner_update"
on public.nexor_whatsapp_inbox
for update
to authenticated
using (owner_id = auth.uid())
with check (owner_id = auth.uid());

comment on table public.nexor_records is 'Flexible per-user Nexor records. Each login owns its own data through owner_id and RLS.';
comment on table public.nexor_whatsapp_inbox is 'Incoming WhatsApp messages to be parsed into Nexor records by an Edge Function.';

-- After creating the first Supabase Auth user for jvgsales72@gmail.com, run:
-- update public.nexor_profiles set app_role = 'admin' where email = 'jvgsales72@gmail.com';
